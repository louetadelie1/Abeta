#!/bin/bash

#SBATCH -J cpujob
#SBATCH -A VENDRUSCOLO-SL3-CPU
#SBATCH -p skylake
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=8
#SBATCH --time=12:00:00
#SBATCH --mail-type=ALL
##SBATCH --no-requeue

export OMP_NUM_THREADS=1

module purge
module load rhel7/default-basic openmpi/3.1.4-gcc-7.2.0 cmake-3.19.7-gcc-5.4-5gbsejo

export PATH=/home/al2108/rds/hpc-work/opt/plumed-2.7.4/bin:$PATH
export LD_LIBRARY_PATH=/home/al2108/rds/hpc-work/opt/plumed-2.7.4/lib:$LD_LIBRARY_PATH
export PATH=/home/al2108/rds/hpc-work/opt/gromacs-2018.8-eef/bin:$PATH
export PLUMED_NUM_THREADS=${OMP_NUM_THREADS}



#mpirun -n 32 gmx_mpi mdrun -s topol -cpi state -multidir conf{0..31} -plumed ../plumed.dat -v -maxh 12 -cpt 60 -cpnum -noappend -nb gpu -ntomp ${SLURM_CPUS_PER_TASK} &>> log

mpirun -np 32 gmx_mpi mdrun -s topol.tpr -multidir conf{0..31} -plumed ../plumed.og.dat -v -nsteps -1 -maxh 11 -ntomp ${OMP_NUM_THREADS} &>> log

###Restart
#mpirun -np 32 gmx_mpi mdrun -s topol -cpi state -multidir conf{0..31} -plumed ../plumed.dat -v -nsteps -1 -maxh 11 -ntomp ${OMP_NUM_THREADS} &>> log

### Restart with extended simulation time:

#mpirun -np 32 gmx_mpi mdrun -s tprout -cpi state -multidir conf{0..31} -plumed ../plumed.dat -v -nsteps -1 -maxh 11 -ntomp ${OMP_NUM_THREADS} &>> log
