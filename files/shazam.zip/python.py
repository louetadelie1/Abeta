import os
import shutil


# In[38]:


# In[39]:


shutil.copy('template.gro', 'protein.complex.gro')


# In[40]:


with open(r"protein.complex.gro", 'r+') as fp:
    lines = fp.readlines()
    fp.seek(0)
    fp.truncate()
    fp.writelines(lines[:-1])

#appending contents of ligand.gro to template.gro
# open both files
with open('../ligand.gro','r') as firstfile, open('protein.complex.gro','a') as secondfile:
    
    # read content from first file
    for line in firstfile:
               
             # append content to second file
             secondfile.write(line)


# In[43]:


with open('template.gro', 'r') as f:
    last_line = f.readlines()[-1]
#y =last_line
y=('  11.00000  11.00000  11.00000')


# In[44]:


destFile = r"protein.complex.gro"
with open(destFile, 'a') as f:
    f.write(y)


# In[45]:


ligand_lines = sum(1 for line in open('../ligand.gro'))
template_lines = sum(1 for line in open('template.gro'))
count=str(template_lines+ligand_lines -3)


# In[46]:


a_file = open("protein.complex.gro", "r")
list_of_lines = a_file.readlines()
list_of_lines[1] = count +"\n"

a_file = open("protein.complex.gro", "w")
a_file.writelines(list_of_lines)
a_file.close()


# In[21]:


index=(5916)
value="\n" + "; Include ligand topology" +"\n" + """#include "../ligand.itp" """ +"\n"


# In[22]:


with open("topol.top", "r") as f:
    contents = f.readlines()

contents.insert(index, value)

with open("topol.top", "w") as f:
    contents = "".join(contents)
    f.write(contents)


# In[23]:


#index2=(21)
#value2="\n" + "; Include ligand parameters" +"\n" + """#include "../../system/ligand.prm" """ +"\n"


# In[24]:


with open("topol.top", "r") as f:
    contents = f.readlines()

contents.insert(index2, value2)

with open("topol.top", "w") as f:
    contents = "".join(contents)
    f.write(contents)


# In[25]:


index3=(5943)
value3="ligand              1"


# In[26]:


with open("topol.top", "r") as f:
    contents = f.readlines()

contents.insert(index3, value3)

with open("topol.top", "w") as f:
    contents = "".join(contents)
    f.write(contents)


# In[ ]:



